void initUART2(long int BaudRate);
void putchar2(unsigned char c);
unsigned char getchar2(void);
void send_string2 (unsigned char * buff);
int get_string2 (unsigned char * buff, int max);
