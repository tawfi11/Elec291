

#if !defined(AFX_STDAFX_H__0581A7FA_DEC6_4D61_B47A_826059363FA9__INCLUDED_)
#define AFX_STDAFX_H__0581A7FA_DEC6_4D61_B47A_826059363FA9__INCLUDED_


#define _CRT_SECURE_NO_WARNINGS  

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <stdio.h>

#include <afxcmn.h>			// MFC support for Windows Common Controls
#include "../Files/Files.h"

// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__0581A7FA_DEC6_4D61_B47A_826059363FA9__INCLUDED_)
