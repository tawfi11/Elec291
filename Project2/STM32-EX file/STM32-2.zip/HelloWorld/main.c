#include <stdio.h>

void main(void)
{
	printf("Hello, World!\r\n");
}
