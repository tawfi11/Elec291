void initADC(void);
int readADC(void);
